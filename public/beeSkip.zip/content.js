/**
 * BeeSkip — YouTube Auto Skip Content Script
 * Primary selector: .ytp-skip-ad-button
 * Animates a bee from wherever it's roaming to the skip button, clicks once, flies away.
 */

const SKIP_SELECTORS = ['.ytp-skip-ad-button', '.ytp-ad-skip-button'];
const AD_SIGNALS = ['#movie_player.ad-showing', '.html5-video-player.ad-showing'];
const STORAGE_KEY = 'beeskip_enabled';
const COUNTER_KEY = 'beeskip_skip_count';
const TIME_KEY    = 'beeskip_time_saved'; // seconds

// ── Home spot (top-right of page, half-hidden, upside down) ──
const BEE_SIZE   = 90;   // must match #beeskip-bee width/height in styles.css
const HOME_RIGHT = 120;  // px from right edge of the page (bigger = further left)
const HOME_PEEK  = 45;   // px of the bee hidden above the top edge (45 = half)

let enabled = true;
let isAnimating = false;
let isRoaming = false;
let observer = null;
let currentBee = null;
let currentSkipBtn = null;
let roamTimer = null;
let lastHandledBtn = null;
let wasAdPlaying = false;
let homeTimer = null;
let runId = 0;
let zoneQueue = [];

function skipSelector() {
  for (const s of SKIP_SELECTORS) {
    try {
      const el = document.querySelector(s);
      if (el) return el;
    } catch (e) {}
  }
  return null;
}

function isButtonVisible(btn) {
  if (!btn) return false;
  const rect = btn.getBoundingClientRect();
  const style = window.getComputedStyle(btn);
  return rect.width > 0 && rect.height > 0 &&
    style.display !== 'none' && style.visibility !== 'hidden' &&
    parseFloat(style.opacity) > 0;
}

function isSkipButton(btn) {
  if (!btn) return false;
  const matches = SKIP_SELECTORS.some(s => { try { return btn.matches(s); } catch (e) { return false; } });
  if (!matches) return false;
  if (!btn.closest('#movie_player, .html5-video-player, .ytp-player-content')) return false;
  const aria = (btn.getAttribute('aria-label') || '').toLowerCase();
  if (aria.includes('navigation')) return false;
  return true;
}

function isButtonClickable(btn) {
  if (!isButtonVisible(btn)) return false;
  if (btn.disabled || btn.getAttribute('aria-disabled') === 'true') return false;
  const style = window.getComputedStyle(btn);
  if (parseFloat(style.opacity) < 0.9) return false;
  return true;
}

function isAdPlaying() {
  return AD_SIGNALS.some(s => { try { return !!document.querySelector(s); } catch (e) { return false; } });
}

function getOppositeEdge(rect) {
  const vw = window.innerWidth, vh = window.innerHeight;
  const cx = rect.left + rect.width / 2;
  const cy = rect.top + rect.height / 2;
  const distances = [
    { edge: 'left', d: cx },
    { edge: 'right', d: vw - cx },
    { edge: 'top', d: cy },
    { edge: 'bottom', d: vh - cy },
  ];
  distances.sort((a, b) => b.d - a.d);
  return distances[0].edge;
}

function createBee() {
  const bee = document.createElement('div');
  bee.id = 'beeskip-bee';
  bee.innerHTML = `<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAxMDAgMTAwIiB3aWR0aD0iMTUwIiBoZWlnaHQ9IjE1MCI+PHBhdGggZD0iTTQwIDQwIEwyNSAyNSBNIDYwIDQwIEwgNzUgMjUgTSAzNSA1NSBMIDIwIDYwIE0gNjUgNTUgTCA4MCA2MCBNIDQwIDcwIEwgMzAgODUgTSA2MCA3MCBMIDcwIDg1IiBzdHJva2U9IiMxQTFBMUEiIHN0cm9rZS13aWR0aD0iMi41IiBzdHJva2UtbGluZWNhcD0icm91bmQiIGZpbGw9Im5vbmUiLz48cG9seWdvbiBwb2ludHM9IjQ4LDg1IDUyLDg1IDUwLDk2IiBmaWxsPSIjMUExQTFBIi8+PGVsbGlwc2UgY3g9IjUwIiBjeT0iNjUiIHJ4PSIxNiIgcnk9IjI0IiBmaWxsPSIjRkZDQzAwIi8+PGNpcmNsZSBjeD0iNTAiIGN5PSIzOCIgcj0iMTQiIGZpbGw9IiNCODg2MGIiLz48ZWxsaXBzZSBjeD0iNTAiIGN5PSIyMiIgcng9IjEwIiByeT0iOCIgZmlsbD0iIzFBMUExQSIvPjxlbGxpcHNlIGN4PSI0MyIgY3k9IjIxIiByeD0iMyIgcnk9IjUiIGZpbGw9IiMzMzMzMzMiLz48ZWxsaXBzZSBjeD0iNTciIGN5PSIyMSIgcng9IjMiIHJ5PSI1IiBmaWxsPSIjMzMzMzMzIi8+PC9zdmc+" alt="bee" class="beeskip-bee-img">`;
  (document.fullscreenElement || document.body).appendChild(bee);
  return bee;
}

function removeBee() {
  if (currentBee && currentBee.parentNode) currentBee.parentNode.removeChild(currentBee);
  currentBee = null;
}

function clearHomeTimer() {
  if (homeTimer) { clearTimeout(homeTimer); homeTimer = null; }
}

function isHome() {
  return !!currentBee && currentBee.classList.contains('beeskip-home');
}

function homePos() {
  return { x: window.innerWidth - HOME_RIGHT - BEE_SIZE, y: -HOME_PEEK };
}

/** Put the bee at its home spot instantly (no animation). */
function showHome() {
  if (!enabled) return;
  const bee = currentBee || createBee();
  currentBee = bee;
  clearHomeTimer();
  const p = homePos();
  bee.style.transition = 'none';
  bee.style.left = p.x + 'px';
  bee.style.top  = p.y + 'px';
  bee.classList.remove('beeskip-flying', 'beeskip-pressing', 'beeskip-leaving');
  bee.classList.add('beeskip-home');
}

/** Fly the bee back to its home spot, then hang upside down. */
function goHome() {
  if (!enabled) return;
  if (!currentBee) { showHome(); return; }
  if (homeTimer || isHome()) return;
  const bee = currentBee;
  const p = homePos();
  bee.classList.remove('beeskip-pressing', 'beeskip-leaving');
  bee.classList.add('beeskip-flying');
  bee.style.transition = 'left 0.9s ease-in-out, top 0.9s ease-in-out';
  bee.style.left = p.x + 'px';
  bee.style.top  = p.y + 'px';
  homeTimer = setTimeout(() => {
    homeTimer = null;
    if (!currentBee || isRoaming || isAnimating) return;
    currentBee.classList.remove('beeskip-flying');
    currentBee.classList.add('beeskip-home');
  }, 950);
}

function cleanupAll() {
  runId++;                       // invalidates any pending skip timers
  if (roamTimer) { clearInterval(roamTimer); roamTimer = null; }
  clearHomeTimer();
  currentSkipBtn = null;
  isAnimating = false;
  isRoaming = false;
  lastHandledBtn = null;
  if (enabled) goHome(); else removeBee();
}

/** Increment skip counter and time saved in chrome.storage.local */
function recordSkip() {
  // Each skip saves between 5–15 s; use a random value in that range
  const savedSeconds = 5 + Math.floor(Math.random() * 11);
  chrome.storage.local.get([COUNTER_KEY, TIME_KEY], (result) => {
    const newCount = (result[COUNTER_KEY] || 0) + 1;
    const newTime  = (result[TIME_KEY]    || 0) + savedSeconds;
    chrome.storage.local.set({ [COUNTER_KEY]: newCount, [TIME_KEY]: newTime });
  });
}

/** Next roam target: walks a shuffled 3x3 grid so the bee covers the whole screen. */
function nextRoamPoint() {
  const vw = window.innerWidth, vh = window.innerHeight;
  if (!zoneQueue.length) {
    for (let r = 0; r < 3; r++) for (let c = 0; c < 3; c++) zoneQueue.push([c, r]);
    for (let i = zoneQueue.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [zoneQueue[i], zoneQueue[j]] = [zoneQueue[j], zoneQueue[i]];
    }
  }
  const [c, r] = zoneQueue.pop();
  const zw = Math.max(0, vw - BEE_SIZE) / 3;
  const zh = Math.max(0, vh - BEE_SIZE) / 3;
  return { x: c * zw + Math.random() * zw, y: r * zh + Math.random() * zh };
}

function startRoaming() {
  if (isRoaming || isAnimating) return;
  if (!enabled) return;
  isRoaming = true;
  clearHomeTimer();
  const bee = currentBee || createBee();
  currentBee = bee;
  if (!bee.style.left) showHome();

  bee.classList.remove('beeskip-home', 'beeskip-leaving', 'beeskip-pressing');
  bee.classList.add('beeskip-flying');
  void bee.offsetWidth; // flush so the first hop animates from the current spot

  const hop = () => {
    if (!currentBee || !isRoaming) return;
    const p = nextRoamPoint();
    currentBee.style.transition = 'left 1.2s ease-in-out, top 1.2s ease-in-out';
    currentBee.style.left = p.x + 'px';
    currentBee.style.top  = p.y + 'px';
  };
  requestAnimationFrame(hop);

  roamTimer = setInterval(() => {
    if (!currentBee || !isAdPlaying()) { stopRoaming(); goHome(); return; }
    hop();
  }, 1300);
}

function stopRoaming() {
  if (roamTimer) { clearInterval(roamTimer); roamTimer = null; }
  isRoaming = false;
}

function doClick(btn) {
  try {
    const rect = btn.getBoundingClientRect();
    const x = rect.left + rect.width  / 2;
    const y = rect.top  + rect.height / 2;
    const opts = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y, button: 0 };

    try { btn.dispatchEvent(new PointerEvent('pointerdown', { ...opts, pointerId: 1, pointerType: 'mouse', isPrimary: true })); } catch (e) {}
    try { btn.dispatchEvent(new MouseEvent('mousedown', opts)); } catch (e) {}
    try { btn.dispatchEvent(new PointerEvent('pointerup',   { ...opts, pointerId: 1, pointerType: 'mouse', isPrimary: true })); } catch (e) {}
    try { btn.dispatchEvent(new MouseEvent('mouseup',  opts)); } catch (e) {}
    try { btn.dispatchEvent(new MouseEvent('click',    opts)); } catch (e) {}
    try { btn.click(); } catch (e) {}
  } catch (e) {}
}

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

async function skipAd(btn) {
  doClick(btn);
  await sleep(500);
  if (!isAdPlaying() || !document.contains(btn)) {
    recordSkip();
    return;
  }

  try {
    await chrome.runtime.sendMessage({
      type: 'TRUSTED_CLICK',
      x: Math.round(btn.getBoundingClientRect().left + btn.getBoundingClientRect().width  / 2),
      y: Math.round(btn.getBoundingClientRect().top  + btn.getBoundingClientRect().height / 2)
    });
  } catch (e) {}
  await sleep(600);

  if (!isAdPlaying()) {
    recordSkip();
    return;
  }

  seekAdToEnd();
  recordSkip();
}

function seekAdToEnd() {
  const v = document.querySelector('#movie_player.ad-showing video, .html5-video-player.ad-showing video');
  if (v && isFinite(v.duration) && v.duration > 0) {
    v.muted = true;
    v.currentTime = v.duration;
  }
}

function flyToAndClick(btn) {
  if (isAnimating) return;
  if (btn === lastHandledBtn) return;
  if (!isSkipButton(btn)) return;

  stopRoaming();
  clearHomeTimer();
  isAnimating = true;
  currentSkipBtn = btn;
  lastHandledBtn = btn;
  const myRun = ++runId;

  const bee = currentBee || createBee();
  currentBee = bee;
  if (!bee.style.left) showHome();

  // Freeze the bee where it is right now (home or mid-roam), then fly to the button
  const cur = bee.getBoundingClientRect();
  bee.style.transition = 'none';
  bee.style.left = cur.left + 'px';
  bee.style.top  = cur.top  + 'px';
  void bee.offsetWidth;

  bee.classList.remove('beeskip-home', 'beeskip-leaving', 'beeskip-pressing');
  bee.classList.add('beeskip-flying');

  const rect = btn.getBoundingClientRect();
  const targetX = rect.left + rect.width  / 2 - 40;
  const targetY = rect.top  + rect.height / 2 - 40;

  const flightStartTime = Date.now();
  const MIN_FLIGHT_DURATION = 800;

  requestAnimationFrame(() => {
    bee.style.transition = 'left 1.0s cubic-bezier(0.25, 1, 0.5, 1), top 1.0s cubic-bezier(0.25, 1, 0.5, 1)';
    bee.style.left = targetX + 'px';
    bee.style.top  = targetY + 'px';

    const waitClickable = setInterval(() => {
      if (myRun !== runId) { clearInterval(waitClickable); return; }
      if (!document.contains(btn)) { clearInterval(waitClickable); cleanupAll(); return; }
      if (Date.now() - flightStartTime >= MIN_FLIGHT_DURATION && isButtonClickable(btn)) {
        clearInterval(waitClickable);
        bee.classList.add('beeskip-pressing');
        skipAd(btn);                       // click logic unchanged
        setTimeout(() => {
          if (myRun !== runId) return;     // already sent home (ad ended)
          cleanupAll();                    // fly home
        }, 900);
      }
    }, 200);
    setTimeout(() => clearInterval(waitClickable), 8000);
  });
}

function trySkip() {
  if (!enabled) return;
  if (isAnimating) return;
  const btn = skipSelector();
  if (!btn) return;
  if (!isSkipButton(btn)) return;
  if (!isButtonVisible(btn)) return;
  if (btn === lastHandledBtn) return;
  flyToAndClick(btn);
}

function checkAdState() {
  if (!enabled) return;
  const ad = isAdPlaying();
  if (ad && !wasAdPlaying) wasAdPlaying = true;
  if (!ad && wasAdPlaying) wasAdPlaying = false;
  if (ad) {
    if (!isRoaming && !isAnimating) startRoaming();
  } else {
    if (isAnimating) { cleanupAll(); return; }
    if (isRoaming) stopRoaming();
    if (!currentBee) showHome();
    else goHome();            // no-op if already home / already on the way
  }
}

let observerBusy = false;
function setupObserver() {
  if (observer) observer.disconnect();
  observer = new MutationObserver(() => {
    if (observerBusy) return;
    observerBusy = true;
    requestAnimationFrame(() => {
      const btn = skipSelector();
      if (btn && isSkipButton(btn) && isButtonVisible(btn) && btn !== lastHandledBtn) {
        trySkip();
      } else {
        checkAdState();
      }
      observerBusy = false;
    });
  });
  observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'style'] });
}

function handleNavigation() {
  cleanupAll();
  setTimeout(() => { checkAdState(); trySkip(); }, 600);
}
document.addEventListener('yt-navigate-finish', handleNavigation);
window.addEventListener('popstate', handleNavigation);

function loadEnabled() {
  chrome.storage.sync.get([STORAGE_KEY], (result) => {
    enabled = result[STORAGE_KEY] !== false;
    if (enabled) { showHome(); checkAdState(); trySkip(); }
  });
}

chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'ENABLED_CHANGED') {
    enabled = message.enabled;
    if (!enabled) cleanupAll();
    else { showHome(); checkAdState(); trySkip(); }
  }
});

window.addEventListener('resize', () => {
  if (currentBee && isHome()) {
    currentBee.style.transition = 'none';
    currentBee.style.left = homePos().x + 'px';
  }
});

// Fullscreen only draws the fullscreen element's children, so move the bee into it
document.addEventListener('fullscreenchange', () => {
  if (!currentBee) return;
  const fs = document.fullscreenElement;
  (fs || document.body).appendChild(currentBee);
  currentBee.classList.toggle('beeskip-fs', !!fs);
});

function init() {
  loadEnabled();
  setupObserver();
  setInterval(() => {
    if (!enabled || isAnimating) return;
    checkAdState();
    trySkip();
  }, 1500);
}

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
else init();