/**
 * BeeSkip — YouTube Auto Skip Content Script
 * Primary selector: .ytp-skip-ad-button
 * Animates a bee from wherever it's roaming to the skip button, clicks once, flies away.
 */

const SKIP_SELECTORS = ['.ytp-skip-ad-button', '.ytp-ad-skip-button'];
const AD_SIGNALS = ['#movie_player.ad-showing', '.html5-video-player.ad-showing'];
const STORAGE_KEY = 'beeskip_enabled';
const COUNTER_KEY = 'beeskip_skip_count';
const TIME_KEY    = 'beeskip_time_saved'; // seconds

let enabled = true;
let isAnimating = false;
let isRoaming = false;
let observer = null;
let currentBee = null;
let currentSkipBtn = null;
let roamTimer = null;
let lastHandledBtn = null;
let wasAdPlaying = false;

function skipSelector() {
  for (const s of SKIP_SELECTORS) {
    try {
      const el = document.querySelector(s);
      if (el) return el;
    } catch (e) {}
  }
  return null;
}

function isButtonVisible(btn) {
  if (!btn) return false;
  const rect = btn.getBoundingClientRect();
  const style = window.getComputedStyle(btn);
  return rect.width > 0 && rect.height > 0 &&
    style.display !== 'none' && style.visibility !== 'hidden' &&
    parseFloat(style.opacity) > 0;
}

function isSkipButton(btn) {
  if (!btn) return false;
  const matches = SKIP_SELECTORS.some(s => { try { return btn.matches(s); } catch (e) { return false; } });
  if (!matches) return false;
  if (!btn.closest('#movie_player, .html5-video-player, .ytp-player-content')) return false;
  const aria = (btn.getAttribute('aria-label') || '').toLowerCase();
  if (aria.includes('navigation')) return false;
  return true;
}

function isButtonClickable(btn) {
  if (!isButtonVisible(btn)) return false;
  if (btn.disabled || btn.getAttribute('aria-disabled') === 'true') return false;
  const style = window.getComputedStyle(btn);
  if (parseFloat(style.opacity) < 0.9) return false;
  return true;
}

function isAdPlaying() {
  return AD_SIGNALS.some(s => { try { return !!document.querySelector(s); } catch (e) { return false; } });
}

function getOppositeEdge(rect) {
  const vw = window.innerWidth, vh = window.innerHeight;
  const cx = rect.left + rect.width / 2;
  const cy = rect.top + rect.height / 2;
  const distances = [
    { edge: 'left', d: cx },
    { edge: 'right', d: vw - cx },
    { edge: 'top', d: cy },
    { edge: 'bottom', d: vh - cy },
  ];
  distances.sort((a, b) => b.d - a.d);
  return distances[0].edge;
}

function createBee() {
  const bee = document.createElement('div');
  bee.id = 'beeskip-bee';
  bee.innerHTML = `<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAxMDAgMTAwIiB3aWR0aD0iMTUwIiBoZWlnaHQ9IjE1MCI+PHBhdGggZD0iTTQwIDQwIEwyNSAyNSBNIDYwIDQwIEwgNzUgMjUgTSAzNSA1NSBMIDIwIDYwIE0gNjUgNTUgTCA4MCA2MCBNIDQwIDcwIEwgMzAgODUgTSA2MCA3MCBMIDcwIDg1IiBzdHJva2U9IiMxQTFBMUEiIHN0cm9rZS13aWR0aD0iMi41IiBzdHJva2UtbGluZWNhcD0icm91bmQiIGZpbGw9Im5vbmUiLz48cG9seWdvbiBwb2ludHM9IjQ4LDg1IDUyLDg1IDUwLDk2IiBmaWxsPSIjMUExQTFBIi8+PGVsbGlwc2UgY3g9IjUwIiBjeT0iNjUiIHJ4PSIxNiIgcnk9IjI0IiBmaWxsPSIjRkZDQzAwIi8+PGNpcmNsZSBjeD0iNTAiIGN5PSIzOCIgcj0iMTQiIGZpbGw9IiNCODg2MGIiLz48ZWxsaXBzZSBjeD0iNTAiIGN5PSIyMiIgcng9IjEwIiByeT0iOCIgZmlsbD0iIzFBMUExQSIvPjxlbGxpcHNlIGN4PSI0MyIgY3k9IjIxIiByeD0iMyIgcnk9IjUiIGZpbGw9IiMzMzMzMzMiLz48ZWxsaXBzZSBjeD0iNTciIGN5PSIyMSIgcng9IjMiIHJ5PSI1IiBmaWxsPSIjMzMzMzMzIi8+PC9zdmc+" alt="bee" class="beeskip-bee-img">`;
  document.body.appendChild(bee);
  return bee;
}

function removeBee() {
  if (currentBee && currentBee.parentNode) currentBee.parentNode.removeChild(currentBee);
  currentBee = null;
}

function cleanupAll() {
  if (roamTimer) { clearInterval(roamTimer); roamTimer = null; }
  removeBee();
  currentSkipBtn = null;
  isAnimating = false;
  isRoaming = false;
  lastHandledBtn = null;
}

/** Increment skip counter and time saved in chrome.storage.local */
function recordSkip() {
  // Each skip saves between 5–15 s; use a random value in that range
  const savedSeconds = 5 + Math.floor(Math.random() * 11);
  chrome.storage.local.get([COUNTER_KEY, TIME_KEY], (result) => {
    const newCount = (result[COUNTER_KEY] || 0) + 1;
    const newTime  = (result[TIME_KEY]    || 0) + savedSeconds;
    chrome.storage.local.set({ [COUNTER_KEY]: newCount, [TIME_KEY]: newTime });
  });
}

function startRoaming() {
  if (isRoaming || isAnimating) return;
  if (!enabled) return;
  isRoaming = true;
  const bee = currentBee || createBee();
  currentBee = bee;
  const vw = window.innerWidth, vh = window.innerHeight;
  const edges = ['left', 'right', 'top', 'bottom'];
  const edge = edges[Math.floor(Math.random() * edges.length)];
  let x, y;
  switch (edge) {
    case 'left':   x = -100;      y = Math.random() * (vh - 100); break;
    case 'right':  x = vw + 100;  y = Math.random() * (vh - 100); break;
    case 'top':    x = Math.random() * (vw - 100); y = -100;      break;
    case 'bottom': x = Math.random() * (vw - 100); y = vh + 100;  break;
  }
  bee.style.transition = 'none';
  bee.style.left = x + 'px';
  bee.style.top  = y + 'px';
  bee.classList.remove('beeskip-leaving', 'beeskip-pressing');
  bee.classList.add('beeskip-flying');

  requestAnimationFrame(() => {
    setTimeout(() => {
      if (!currentBee || !isRoaming) return;
      const nx = 60 + Math.random() * (vw - 120);
      const ny = 60 + Math.random() * (vh - 120);
      currentBee.style.transition = 'left 1.2s ease-in-out, top 1.2s ease-in-out';
      currentBee.style.left = nx + 'px';
      currentBee.style.top  = ny + 'px';
    }, 20);
  });

  roamTimer = setInterval(() => {
    if (!currentBee || !isAdPlaying()) { stopRoaming(); return; }
    const nx = 60 + Math.random() * (vw - 120);
    const ny = 60 + Math.random() * (vh - 120);
    currentBee.style.transition = 'left 1.2s ease-in-out, top 1.2s ease-in-out';
    currentBee.style.left = nx + 'px';
    currentBee.style.top  = ny + 'px';
  }, 1300);
}

function stopRoaming() {
  if (roamTimer) { clearInterval(roamTimer); roamTimer = null; }
  isRoaming = false;
}

function doClick(btn) {
  try {
    const rect = btn.getBoundingClientRect();
    const x = rect.left + rect.width  / 2;
    const y = rect.top  + rect.height / 2;
    const opts = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y, button: 0 };

    try { btn.dispatchEvent(new PointerEvent('pointerdown', { ...opts, pointerId: 1, pointerType: 'mouse', isPrimary: true })); } catch (e) {}
    try { btn.dispatchEvent(new MouseEvent('mousedown', opts)); } catch (e) {}
    try { btn.dispatchEvent(new PointerEvent('pointerup',   { ...opts, pointerId: 1, pointerType: 'mouse', isPrimary: true })); } catch (e) {}
    try { btn.dispatchEvent(new MouseEvent('mouseup',  opts)); } catch (e) {}
    try { btn.dispatchEvent(new MouseEvent('click',    opts)); } catch (e) {}
    try { btn.click(); } catch (e) {}
  } catch (e) {}
}

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

async function skipAd(btn) {
  doClick(btn);
  await sleep(500);
  if (!isAdPlaying() || !document.contains(btn)) {
    recordSkip();
    return;
  }

  try {
    await chrome.runtime.sendMessage({
      type: 'TRUSTED_CLICK',
      x: Math.round(btn.getBoundingClientRect().left + btn.getBoundingClientRect().width  / 2),
      y: Math.round(btn.getBoundingClientRect().top  + btn.getBoundingClientRect().height / 2)
    });
  } catch (e) {}
  await sleep(600);

  if (!isAdPlaying()) {
    recordSkip();
    return;
  }

  seekAdToEnd();
  recordSkip();
}

function seekAdToEnd() {
  const v = document.querySelector('#movie_player.ad-showing video, .html5-video-player.ad-showing video');
  if (v && isFinite(v.duration) && v.duration > 0) {
    v.muted = true;
    v.currentTime = v.duration;
  }
}

function flyToAndClick(btn) {
  if (isAnimating) return;
  if (btn === lastHandledBtn) return;
  if (!isSkipButton(btn)) return;

  stopRoaming();
  isAnimating = true;
  currentSkipBtn = btn;
  lastHandledBtn = btn;

  const bee = currentBee || createBee();
  currentBee = bee;

  const rect = btn.getBoundingClientRect();
  const vw = window.innerWidth, vh = window.innerHeight;
  const edge = getOppositeEdge(rect);

  const isAlreadyOnScreen = document.body.contains(bee) && bee.style.left !== '' && bee.style.left !== undefined;

  if (isAlreadyOnScreen) {
    const cur = bee.getBoundingClientRect();
    bee.style.transition = 'none';
    bee.style.left = cur.left + 'px';
    bee.style.top  = cur.top  + 'px';
    void bee.offsetWidth;
  } else {
    let startX, startY;
    switch (edge) {
      case 'left':   startX = -120;      startY = rect.top  + rect.height / 2 - 40; break;
      case 'right':  startX = vw + 120;  startY = rect.top  + rect.height / 2 - 40; break;
      case 'top':    startX = rect.left  + rect.width  / 2 - 40; startY = -120;     break;
      case 'bottom': startX = rect.left  + rect.width  / 2 - 40; startY = vh + 120; break;
    }
    bee.style.transition = 'none';
    bee.style.left = startX + 'px';
    bee.style.top  = startY + 'px';
    void bee.offsetWidth;
  }

  bee.classList.remove('beeskip-leaving', 'beeskip-pressing');
  bee.classList.add('beeskip-flying');

  const targetX = rect.left + rect.width  / 2 - 40;
  const targetY = rect.top  + rect.height / 2 - 40;

  const exitX = edge === 'left' ? -120 : edge === 'right' ? vw + 120 : targetX;
  const exitY = edge === 'top'  ? -120 : edge === 'bottom' ? vh + 120 : targetY;

  const flightStartTime = Date.now();
  const MIN_FLIGHT_DURATION = 800;

  requestAnimationFrame(() => {
    bee.style.transition = 'left 1.0s cubic-bezier(0.25, 1, 0.5, 1), top 1.0s cubic-bezier(0.25, 1, 0.5, 1)';
    bee.style.left = targetX + 'px';
    bee.style.top  = targetY + 'px';

    const waitClickable = setInterval(() => {
      if (!document.contains(btn)) { clearInterval(waitClickable); cleanupAll(); return; }
      if (Date.now() - flightStartTime >= MIN_FLIGHT_DURATION && isButtonClickable(btn)) {
        clearInterval(waitClickable);
        bee.classList.add('beeskip-pressing');
        skipAd(btn);

        setTimeout(() => {
          bee.style.transition = 'left 0.7s ease-in-out, top 0.7s ease-in-out';
          bee.style.left = exitX + 'px';
          bee.style.top  = exitY + 'px';
          bee.classList.remove('beeskip-pressing');
          bee.classList.add('beeskip-leaving');
          setTimeout(cleanupAll, 800);
        }, 1200);
      }
    }, 200);
    setTimeout(() => clearInterval(waitClickable), 8000);
  });
}

function trySkip() {
  if (!enabled) return;
  if (isAnimating) return;
  const btn = skipSelector();
  if (!btn) return;
  if (!isSkipButton(btn)) return;
  if (!isButtonVisible(btn)) return;
  if (btn === lastHandledBtn) return;
  flyToAndClick(btn);
}

function checkAdState() {
  if (!enabled) return;
  const ad = isAdPlaying();
  if (ad && !wasAdPlaying) wasAdPlaying = true;
  if (!ad && wasAdPlaying) wasAdPlaying = false;
  if (ad) {
    if (!isRoaming && !isAnimating) startRoaming();
  } else {
    if (isRoaming) stopRoaming();
    if (isAnimating) cleanupAll();
  }
}

let observerBusy = false;
function setupObserver() {
  if (observer) observer.disconnect();
  observer = new MutationObserver(() => {
    if (observerBusy) return;
    observerBusy = true;
    requestAnimationFrame(() => {
      const btn = skipSelector();
      if (btn && isSkipButton(btn) && isButtonVisible(btn) && btn !== lastHandledBtn) {
        trySkip();
      } else {
        checkAdState();
      }
      observerBusy = false;
    });
  });
  observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'style'] });
}

function handleNavigation() {
  cleanupAll();
  setTimeout(() => { checkAdState(); trySkip(); }, 600);
}
document.addEventListener('yt-navigate-finish', handleNavigation);
window.addEventListener('popstate', handleNavigation);

function loadEnabled() {
  chrome.storage.sync.get([STORAGE_KEY], (result) => {
    enabled = result[STORAGE_KEY] !== false;
    if (enabled) { checkAdState(); trySkip(); }
  });
}

chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'ENABLED_CHANGED') {
    enabled = message.enabled;
    if (!enabled) cleanupAll();
    else { checkAdState(); trySkip(); }
  }
});

function init() {
  loadEnabled();
  setupObserver();
  setInterval(() => {
    if (!enabled || isAnimating) return;
    checkAdState();
    trySkip();
  }, 1500);
}

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
else init();