/**
 * BeeSkip Background Service Worker
 */

const STORAGE_KEY = 'beeskip_enabled';
const DEFAULT_ENABLED = true;

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.get([STORAGE_KEY], (result) => {
    if (result[STORAGE_KEY] === undefined) {
      chrome.storage.sync.set({ [STORAGE_KEY]: DEFAULT_ENABLED });
    }
  });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'GET_ENABLED') {
    chrome.storage.sync.get([STORAGE_KEY], (result) => {
      sendResponse({ enabled: result[STORAGE_KEY] !== false });
    });
    return true;
  }

  if (message.type === 'SET_ENABLED') {
    chrome.storage.sync.set({ [STORAGE_KEY]: message.enabled }, () => {
      chrome.tabs.query({ url: '*://*.youtube.com/*' }, (tabs) => {
        tabs.forEach((tab) => {
          chrome.tabs.sendMessage(tab.id, { type: 'ENABLED_CHANGED', enabled: message.enabled }).catch(() => {});
        });
      });
      sendResponse({ success: true });
    });
    return true;
  }
});

// Trusted (isTrusted=true) mouse click via the DevTools protocol.
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type !== 'TRUSTED_CLICK' || !sender.tab) return;
  const target = { tabId: sender.tab.id };
  const { x, y } = message;
  const send = (method, params) => new Promise((res, rej) =>
    chrome.debugger.sendCommand(target, method, params, (r) =>
      chrome.runtime.lastError ? rej(chrome.runtime.lastError) : res(r)));

  chrome.debugger.attach(target, '1.3', async () => {
    if (chrome.runtime.lastError) { sendResponse({ ok: false, error: chrome.runtime.lastError.message }); return; }
    try {
      const base = { x, y, button: 'left', clickCount: 1 };
      await send('Input.dispatchMouseEvent', { type: 'mouseMoved', x, y });
      await send('Input.dispatchMouseEvent', { ...base, type: 'mousePressed' });
      await send('Input.dispatchMouseEvent', { ...base, type: 'mouseReleased' });
      sendResponse({ ok: true });
    } catch (e) {
      sendResponse({ ok: false, error: String(e.message || e) });
    } finally {
      chrome.debugger.detach(target, () => void chrome.runtime.lastError);
    }
  });
  return true;
});
