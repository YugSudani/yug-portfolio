/**
 * BeeSkip Popup Logic
 * Handles enable/disable toggle, status display, and skip/time-saved counters.
 */

const STORAGE_KEY  = 'beeskip_enabled';
const COUNTER_KEY  = 'beeskip_skip_count';
const TIME_KEY     = 'beeskip_time_saved'; // seconds

const toggle      = document.getElementById('toggle');
const statusBar   = document.getElementById('status');
const statusText  = document.getElementById('status-text');
const skipCountEl = document.getElementById('skip-count');
const timeSavedEl = document.getElementById('time-saved');
const creatorLink = document.getElementById('creator-link');

/* ── Helpers ── */
function formatTime(seconds) {
  if (seconds < 60)  return seconds + 's';
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  if (m < 60) return s > 0 ? `${m}m ${s}s` : `${m}m`;
  const h = Math.floor(m / 60);
  const rm = m % 60;
  return rm > 0 ? `${h}h ${rm}m` : `${h}h`;
}

function setStatus(enabled) {
  statusBar.className = 'status-bar ' + (enabled ? 'active' : 'inactive');
  statusText.textContent = enabled
    ? '🍯 Hive active — watching for skip buttons'
    : '💤 Resting — auto-skip paused';
}

/* ── Load stored settings ── */
chrome.storage.sync.get([STORAGE_KEY], (syncResult) => {
  const enabled = syncResult[STORAGE_KEY] !== false;
  toggle.checked = enabled;
  setStatus(enabled);
});

chrome.storage.local.get([COUNTER_KEY, TIME_KEY], (localResult) => {
  skipCountEl.textContent = localResult[COUNTER_KEY] || 0;
  timeSavedEl.textContent = formatTime(localResult[TIME_KEY] || 0);
});

/* ── Live-update stats when content script writes them ── */
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local') {
    if (changes[COUNTER_KEY]) skipCountEl.textContent = changes[COUNTER_KEY].newValue;
    if (changes[TIME_KEY])    timeSavedEl.textContent = formatTime(changes[TIME_KEY].newValue);
  }
});

/* ── Toggle ── */
toggle.addEventListener('change', () => {
  const enabled = toggle.checked;
  chrome.runtime.sendMessage({ type: 'SET_ENABLED', enabled }, () => {
    setStatus(enabled);
  });
});

/* ── Creator link — open in new tab ── */
if (creatorLink) {
  creatorLink.addEventListener('click', (e) => {
    e.preventDefault();
    chrome.tabs.create({ url: 'https://yug-ptdf.onrender.com/' });
  });
}